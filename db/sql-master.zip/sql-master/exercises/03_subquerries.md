Skorzystaj z bazy `library_db.sql`

---

1. Podaj najpopularniejszego autora dla każdego użytkownika
2. Podaj najaktywniejszego użytkownika dla każdego autora

---

3. Podaj listę użytkowników, którzy przez cały okres działalności biblioteki pożyczyli więcej książek niż przeciętny użytkownik
4. Podaj listę użytkowników, którzy w 1995 r. pożyczyli więcej książek niż przeciętny użytkownik
5. Dla każdego użytkownika podaj, rok, w którym pożyczył najwięcej książek