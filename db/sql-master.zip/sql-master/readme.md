# SQL

 * Pobierz program do obsługi bazy danych: https://sqlitebrowser.org/
 * *Cheatsheet* z podstawowymi zapytaniami znajdziesz w pliku `sql_manual.md`
 * *Cheatsheet*  do zapytania `SELECT` znajdziesz w pliku `select_manual.md`
 * Bazy danych do zaimportowania w programie *DB Browser* znajdują się w plikach `simple_library_db.csv` oraz `library_db.sql` - w każdym pliku z zestawem zadań znajdziesz informację, z której bazy powinieneś skorzystać
 * Schemat bazy danych z pliku `library_db.sql` znajdziesz w pliku `library_db_scheme.png`
 * Zadania znajdziesz w katalogu `excercises`